# About Dataset (Need to read)
## Overview:
Information on location and characteristics of crashes in Queensland for all reported Road Traffic Crashes occurred from 1 January 2001 to 31 December 2021, fatal, hospitalisation, medical treatment and minor injury crashes to 31 December 2021 and property damage only crashes to 31 December 2010.

## Fatal, Hospitalisation, Medical treatment and Minor injury:
This dataset contains information on crashes reported to the police which resulted from the movement of at least 1 road vehicle on a road or road related area. Crashes listed in this resource have occurred on a public road and meet one of the following criteria:
a person is killed or injured, or
at least 1 vehicle was towed away, or
the value of the property damage meets the appropriate criteria listed below.

## Property damage:
$2500 or more damage to property other than vehicles (after 1 December 1999)
$2500 or more damage to vehicle and/or other property (after 1 December 1991 and before 1 December 1999)
value of property damage is greater than $1000 (before December 1991).

## Please note:
This data has been extracted from the Queensland Road Crash Database.
Information held in the Road Crash Database on events occurring within the last 12 months is considered preliminary as investigations into crashes can take up to 1 year to finalise.
Property damage only crashes ceased to be reported/recorded by Queensland Police Service after 31 December 2010.
These crash location coordinates reference the current Australian geodetic datum is GDA2020 (previously it was GDA94).

## Explain data
### crash_data_queensland_1_crash_locations.csv:

   - Crash_Ref_Number: A reference number assigned to the crash incident.
   - Crash_Severity: The severity level of the crash (e.g., Hospitalisation, Property damage only, Minor injury).
   - Crash_Year: The year in which the crash occurred.
   - Crash_Month: The month in which the crash occurred.
   - Crash_Day_Of_Week: The day of the week on which the crash occurred.
   - Crash_Hour: The hour at which the crash occurred.
   - Crash_Nature: The nature of the crash (e.g., Head-on, Rear-end, Hit object).
   - Crash_Type: The type of crash (e.g., Multi-Vehicle, Single Vehicle).
   - Crash_Longitude: The longitude coordinate of the crash location.
   - Crash_Latitude: The latitude coordinate of the crash location.
   - Crash_Street: The street where the crash occurred.
   - Crash_Street_Intersecting: The intersecting street, if applicable.
   - State_Road_Name: The name of the state road, if applicable.
   - Loc_Suburb: The suburb where the crash occurred.
   - Loc_Local_Government_Area: The local government area where the crash occurred.
   - Loc_Post_Code: The postal code of the crash location.
   - Loc_Police_Division: The police division responsible for the crash location.
   - Loc_Police_District: The police district responsible for the crash location.
   - Loc_Police_Region: The police region responsible for the crash location.
   - Loc_Queensland_Transport_Region: The Queensland transport region of the crash location.
   - Loc_Main_Roads_Region: The main roads region of the crash location.
   - Loc_ABS_Statistical_Area_2: The ABS (Australian Bureau of Statistics) statistical area 2 of the crash location.
   - Loc_ABS_Statistical_Area_3: The ABS statistical area 3 of the crash location.
   - Loc_ABS_Statistical_Area_4: The ABS statistical area 4 of the crash location.
   - Loc_ABS_Remoteness: The ABS remoteness classification of the crash location.
   - Loc_State_Electorate: The state electorate of the crash location.
   - Loc_Federal_Electorate: The federal electorate of the crash location.
   - Crash_Controlling_Authority: The authority responsible for controlling the crash (e.g., Locally-controlled).
   - Crash_Roadway_Feature: The feature of the roadway where the crash occurred (e.g., No Roadway Feature, Intersection - Cross).
   - Crash_Traffic_Control: The traffic control measures at the crash location (e.g., No traffic control, Operating traffic lights).
   - Crash_Speed_Limit: The speed limit at the crash location.
   - Crash_Road_Surface_Condition: The surface condition of the road at the crash location.
   - Crash_Atmospheric_Condition: The atmospheric condition at the time of the crash.
   - Crash_Lighting_Condition: The lighting condition at the time of the crash.
   - Crash_Road_Horiz_Align: The horizontal alignment of the road at the crash location.
   - Crash_Road_Vert_Align: The vertical alignment of the road at the crash location.
   - Crash_DCA_Code: The code assigned to the crash by the Department of Customer Service (DCA).
   - Crash_DCA_Description: A description of the crash as per the DCA code.
   - Crash_DCA_Group_Description: A broader description group of the crash by DCA.
   - DCA_Key_Approach_Dir: The key approach direction of the vehicles involved in the crash.
   - Count_Casualty_Fatality: The count of casualties who suffered fatalities.
   - Count_Casualty_Hospitalised: The count of casualties who were hospitalized.
   - Count_Casualty_MedicallyTreated: The count of casualties who received medical treatment.
   - Count_Casualty_MinorInjury: The count of casualties who sustained minor injuries.
   - Count_Casualty_Total: The total count of casualties involved in the crash.
   - Count_Unit_Car: The count of cars involved in the crash.
   - Count_Unit_Motorcycle_Moped: The count of motorcycles/mopeds involved in the crash.
   - Count_Unit_Truck: The count of trucks involved in the crash.
   - Count_Unit_Bus: The count of buses involved in the crash.
   - Count_Unit_Bicycle: The count of bicycles involved in the crash.
   - Count_Unit_Pedestrian: The count of pedestrians involved in the crash.
   - Count_Unit_Other: The count of other units involved in the crash.

### crash_data_queensland_a_road_casualties.csv
   - Crash_Year: The year in which the crash occurred.
   - Crash_Police_Region: The region where the crash was reported to the police.
   - Casualty_Severity: The severity of the casualty (e.g., fatal, medically treated).
   - Casualty_AgeGroup: The age group of the casualty.
   - Casualty_Gender: The gender of the casualty.
   - Casualty_RoadUserType: The type of road user involved in the crash (e.g., driver, pedestrian).
   - Casualty_Count: The count of casualties for each entry.

### crash_data_queensland_b_driver_involvement.csv
   - Crash_Year: The year in which the crash occurred.
   - Crash_Police_Region: The region where the crash was reported to the police.
   - Crash_Severity: The severity of the crash.
   - Involving_Male_Driver: Indicates if a male driver was involved in the crash (Yes/No).
   - Involving_Female_Driver: Indicates if a female driver was involved in the crash (Yes/No).
   - Involving_Young_Driver_16-24: Indicates if a young driver (aged 16-24) was involved in the crash (Yes/No).
   - Involving_Senior_Driver_60plus: Indicates if a senior driver (aged 60 or above) was involved in the crash (Yes/No).
   - Involving_Provisional_Driver: Indicates if a provisional driver was involved in the crash (Yes/No).
   - Involving_Overseas_Licensed_Driver: Indicates if an overseas licensed driver was involved in the crash (Yes/No).
   - Involving_Unlicensed_Driver: Indicates if an unlicensed driver was involved in the crash (Yes/No).
   - Count_Crashes: The count of crashes for each entry.
   - Count_Casualty_Fatality: The count of fatalities for each entry.
   - Count_Casualty_Hospitalised: The count of casualties hospitalized for each entry.
   - Count_Casualty_MedicallyTreated: The count of casualties medically treated for each entry.
   - Count_Casualty_MinorInjury: The count of casualties with minor injuries for each entry.
   - Count_Casualty_All: The count of all casualties for each entry.

### crash_data_queensland_c_restraint_helmet_use.csv
   - Crash_Year: The year in which the crash occurred.
   - Crash_PoliceRegion: The region where the crash was reported to the police.
   - Casualty_Severity: The severity of the casualty.
   - Casualty_AgeGroup: The age group of the casualty.
   - Casualty_Gender: The gender of the casualty.
   - Casualty_Road_User_Type: The type of road user involved in the crash.
   - Casualty_Restraint_Helmet_Use: The use of restraint or helmet by the casualty.
   - Casualty_Count: The count of casualties for each entry.

### crash_data_queensland_d_vehicle_involvement.csv
   - Crash_Year: The year in which the crash occurred.
   - Crash_Police_Region: The region where the crash was reported to the police.
   - Crash_Severity: The severity of the crash.
   - Involving_Motorcycle_Moped: Indicates if a motorcycle/moped was involved in the crash (Yes/No).
   - Involving_Truck: Indicates if a truck was involved in the crash (Yes/No).
   - Involving_Bus: Indicates if a bus was involved in the crash (Yes/No).
   - Count_Crashes: The count of crashes for each entry.
   - Count_Casualty_Fatality: The count of fatalities for each entry.
   - Count_Casualty_Hospitalised: The count of casualties hospitalized for each entry.
   - Count_Casualty_MedicallyTreated: The count of casualties medically treated for each entry.
   - Count_Casualty_MinorInjury: The count of casualties with minor injuries for each entry.
   - Count_Casualty_All: The count of all casualties for each entry.

### crash_data_queensland_e_alcohol_speed_fatigue_defect.csv
   - Crash_Year: The year in which the crash occurred.
   - Crash_Police_Region: The region where the crash was reported to the police.
   - Crash_Severity: The severity of the crash.
   - Involving_Drink_Driving: Indicates if drink driving was involved in the crash (Yes/No).
   - Involving_Driver_Speed: Indicates if driver speed was involved in the crash (Yes/No).
   - Involving_Fatigued_Driver: Indicates if driver fatigue was involved in the crash (Yes/No).
   - Involving_Defective_Vehicle: Indicates if a defective vehicle was involved in the crash (Yes/No).
   - Count_Crashes: The count of crashes for each entry.
   - Count_Fatality: The count of fatalities for each entry.
   - Count_Hospitalised: The count of casualties hospitalized for each entry.
   - Count_Medically_Treated: The count of casualties medically treated for each entry.
   - Count_Minor_Injury: The count of casualties with minor injuries for each entry.
   - Count_All_Casualties: The count of all casualties for each entry.

# Question Entry Test - Tableau: 
With the provided dataset, create a specific report dashboard so that observers can understand the general information about traffic accidents as well as identify patterns, common characteristics of a traffic accident, and propose solutions to reduce traffic accidents in Queensland.

## THIS INFORMATION MUST HAVE IN YOUR TABLEAU ASSIGNMENT
You must have 5 (five) dashboard and 1 (one) storytelling in your tableau assignment
See question below

### A. Crash by Time:

1. Can you create a Tableau dashboard that displays the trend of crash transactions over time, categorized by quarters, and shows a clear distinction between the transactions that led to property damage versus those that caused human harm? Include visual cues to differentiate between the two types of incidents.
2. How would you enhance a Tableau time series chart to depict both the number and percentage of crash-related incidents, adjusting the default settings to harmonize color schemes, size, and coordinate axis for better visual appeal, as well as provide detailed explanations of the dashboard elements?

### B. Crash Severity Analysis:

1. In Tableau, can you categorize and visualize crash incidents by severity levels such as Fatal, Hospitalization, Medical Treatment, Minor Injury, and Property Damage, and analyze the distribution of these categories by time of day and day of the week?
2. How would you develop a Tableau dashboard that offers an in-depth analysis of crash severity in relation to user type and time, adjusting the visual representation for clarity and providing a comprehensive explanation of the dashboard to the stakeholders?

### C. Vehicle and Participant Analysis:

1. How would you design a Tableau dashboard that categorizes crashes by vehicle type and road user involvement, highlighting the most common combinations of vehicle types in these incidents?
2. Can you create a Tableau visualization that investigates the frequency of crashes involving motorcycles, trucks, and buses over time, including capabilities to adjust visual elements for clarity and detailed dashboard explanations?

### D. Road Casualties Analysis:

1. In Tableau, how would you analyze and visualize the severity of road casualties by age group and gender, including the ability to interactively filter and group casualties based on the road user types most affected?
2. Can you develop a comprehensive Tableau dashboard that provides a detailed analysis of road casualties, incorporating geographic (map-based) data and temporal trends, while ensuring the visual harmony of the dashboard elements?

### E. Restraint and Helmet Use Analysis:

1. How would you construct a Tableau dashboard to evaluate the correlation between restraint and helmet use with casualty severity, including age distribution and impact on fatality rates in vehicle occupants?
2. Can you create an advanced Tableau visualization that details restraint and helmet use over time, with interactive filters and an aesthetically decorated dashboard that clearly explains the findings?

### F. Storytelling

1. Can you create a compelling story in Tableau that presents the analysis of a complex dataset, ensuring that your story contains at least two insightful observations and explains the results in more than 50 words? Additionally, ensure that your storytelling does not rely on the default settings and incorporates a touch of humor.
2. How would you design a professional and interactive Tableau story that not only processes data efficiently in various scenarios but also provides at least four key insights? Your story should exhibit advanced understanding and problem-solving skills within Tableau, such as using non-default chart types and templates, and the narrative should be grammatically correct and succinct, yet informative.